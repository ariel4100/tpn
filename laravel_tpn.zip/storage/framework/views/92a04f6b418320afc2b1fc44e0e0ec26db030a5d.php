<?php $__env->startSection('style'); ?>
    <style>
        /*p{*/
            /*font-family: 'Montserrat Light'*/
        /*}*/
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <?php $__empty_1 = true; $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php if($k%2 == 0): ?>
            <div class="row my-5 align-items-center">
                <div class="col-md-6 wow fadeInLeft">
                    <h4 class="tpn-blue font-weight-bold"><?php echo $s->title; ?></h4>
                    <?php echo $s->text; ?>

                </div>
                <div class="col-md-6 wow fadeInRight">
                    <img src="<?php echo $s->image; ?>" alt="" class="img-fluid">
                </div>
            </div>
        <?php else: ?>
            <div class="row my-5 align-items-center">
                <div class="col-md-6 wow fadeInLeft">
                    <img src="<?php echo $s->image; ?>" alt="" class="img-fluid">
                </div>
                <div class="col-md-6 wow fadeInRight">
                    <h4 class="tpn-blue font-weight-bold"><?php echo $s->title; ?></h4>
                    <?php echo $s->text; ?>

                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h4>No hay registros</h4>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>