<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('page.partials.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container my-5">
    <h4 class="tpn-blue font-weight-bold mb-5 wow fadeInDown"><?php echo $empresa->title; ?></h4>
    <div class="row">
        <div class="col-md-8 wow fadeInLeft" style="/*font-family: 'Montserrat Light'*/">
            <?php echo $empresa->text; ?>

        </div>
        <div class="col-md-4 wow fadeInRight">
            <img src="<?php echo asset($empresa->image); ?>" class="img-fluid" alt="">
        </div>
    </div>
</div>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <iframe width="100%" height="400" src="https://www.youtube.com/embed/<?php echo $empresa->video; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
</div>
<div class="container-fluid " style="background-color: #F5F5F5;">
    <div class="container py-5">
        <h4 class="tpn-blue font-weight-bold  wow fadeInDown"><?php echo $empresa->subtitle; ?></h4>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $equipamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-3 wow fadeInUp" data-wow-delay="0.<?php echo e($k*2); ?>s">
                <img src="<?php echo asset($e->image); ?>" alt="" class="img-fluid my-4" >
                <?php echo $e->text; ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>No hay registros</h4>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>