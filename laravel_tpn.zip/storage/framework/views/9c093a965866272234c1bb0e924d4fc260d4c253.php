<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <a class="text-decoration-none " href="<?php echo e(route('usuario.index')); ?>"><< Volver</a>
        <form class="row justify-content-center" method="POST" action="<?php echo e(route('usuario.update',$user->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="col-md-6">
                <div class="md-form">
                    <input type="text" id="Nombre" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($user->name); ?>" required>
                    <label for="Nombre">Nombre</label>
                </div>
                <?php if($errors->has('name')): ?>
                    <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="md-form">
                    <input type="text" id="Usuario" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e($user->username); ?>" required>
                    <label for="Usuario">Nombre de Usuario</label>
                </div>
                <?php if($errors->has('username')): ?>
                    <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('username')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <div class="md-form">
                    <input type="email" id="Email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($user->email); ?>" required>
                    <label for="Email">Email</label>
                </div>
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
                <?php endif; ?>
            </div>

            <div class="col-md-6">
                <div class="md-form">
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <label for="password">Contraseña</label>
                </div>
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="md-form">
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    <label for="password-confirm">Confirmar Contraseña</label>
                </div>
            </div>
            <div class="col-md-12 text-right">
                <button type="submit" class="btn btn-danger">Actualizar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>