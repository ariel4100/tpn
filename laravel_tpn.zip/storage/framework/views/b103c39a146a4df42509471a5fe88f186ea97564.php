<?php $__env->startSection('style'); ?>
    <style>
        .list-group-item {
            position: relative;
            display: block;
            padding: .50rem 1.25rem;
            margin-bottom: -1px;
            background-color: #fff;
            border: unset;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('page.partials.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container my-5">
    <div class="row ">
        <div class="col-md-6 wow fadeInUp">
            <h4 class="font-weight-bold tpn-blue"><?php echo $home->text; ?></h4>
            <a href="<?php echo e(route('servicios')); ?>" class="btn btn-danger">MÁS SERVICIOS</a>
        </div>
        <div class="col-md-6 fadeInDown">
            <ul class="list-group">
                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item wow fadeInUp d-flex align-items-center" data-wow-delay="0.<?php echo e($k*2); ?>s">
                        <img src="<?php echo $s->image; ?>" alt="" class="img-fluid mr-4" style="width: 30px">
                        <?php echo $s->title; ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php if(count($equipamientos) > 0): ?>
<div class="container-fluid " style="background-color: #F5F5F5">
    <div class="container py-5">
        <h4 class="tpn-blue font-weight-bold  wow fadeInDown"><?php echo $empresa->subtitle; ?></h4>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $equipamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3 wow fadeInUp" data-wow-delay="0.<?php echo e($k*2); ?>s">
                    <img src="<?php echo $e->image; ?>" alt="" class="img-fluid my-4" >
                    <?php echo $e->text; ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>No hay registros</h4>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <img src="<?php echo e($home->image); ?>" class="img-fluid" alt="">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>