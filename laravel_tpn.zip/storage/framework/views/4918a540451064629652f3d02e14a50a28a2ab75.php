<?php $__env->startSection('content'); ?>

<div class="container my-5">
    <div class="row">
        <div class="col-md-9">
            <!--Carousel Wrapper-->
            <span class="tpn-blue p-2 font-weight-bold" style="background-color: #ECECEC;"><?php echo $news->Category->title; ?></span>
            <div id="carousel-example-1z" class="carousel slide carousel-fade" data-ride="carousel">
                <!--Indicators-->

                <ol class="carousel-indicators">
                    <?php if($news->image): ?>
                        <li data-target="#carousel-example-1z" data-slide-to="0" class="active"></li>
                    <?php endif; ?>
                <?php $__empty_1 = true; $__currentLoopData = $galery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li data-target="#carousel-example-1z" data-slide-to="<?php echo e($k+1); ?>"  ></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </ol>
                <!--/.Indicators-->
                <!--Slides-->
                <div class="carousel-inner" role="listbox">
                    <?php if($news->image): ?>
                        <div class="carousel-item  active">
                            <img class="d-block w-100" src="<?php echo $news->image; ?>"
                                 alt="First slide">
                        </div>
                    <?php endif; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $galery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="carousel-item">
                        <img class="d-block w-100" src="<?php echo $item->image; ?>"
                             alt="First slide">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <img src="<?php echo $news->image; ?>" alt="" class="img-fluid">
                    <?php endif; ?>
                </div>
                <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <!--/.Carousel Wrapper-->
            <h4 class="tpn-blue font-weight-bold my-4"><?php echo $news->title; ?></h4>
            <?php echo $news->text; ?>

            <div class="card z-depth-0 rounded-0 p-5 my-5" style="background-color: #F9F9F9">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <p class="tpn-blue">Para más información,
                            mirá el video a continuación</p>
                    </div>
                    <div class="col-md-6">

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <h4 class="mb-4 tpn-red">Categorias</h4>
            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <p class="m-0"><a href="" class="" style="color: #000;">>> <?php echo $c->title; ?></a></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No hay registros</p>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>