<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('metadatos.index')); ?>"><< Volver</a>
        <form class="row" method="POST" action="<?php echo e(route('metadatos.update',$metadato->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="col-md-12">
                <div class="md-form">
                    <input type="text" id="seccion" name="seccion"  class="form-control" value="<?php echo e($metadato->seccion); ?>" readonly="readonly" >
                    <label for="seccion" class="">Seccion</label>
                </div>
            </div>
            <div class="col-md-6">
                <div class="md-form">
                    <textarea id="keyword" class="md-textarea form-control" name="keyword" rows="3"><?php echo e($metadato->keyword); ?></textarea>
                    <label for="keyword" class="">keyword</label>
                    <small class="text-muted">Palabras separados por ( , )</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="md-form">
                    <textarea id="Descripcion" class="md-textarea form-control" name="descripcion" rows="3"><?php echo e($metadato->descripcion); ?></textarea>
                    <label for="Descripcion" class="">Descripcion</label>
                </div>
            </div>
            <div class="col-md-12 my-4 text-right">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>