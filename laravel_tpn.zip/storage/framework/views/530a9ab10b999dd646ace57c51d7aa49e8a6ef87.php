<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <h4 class="tpn-blue font-weight-bold my-4"><?php echo $data->title; ?></h4>
    <div class="row">
        <div class="col-md-6 wow fadeInUp" style="/*font-family: Montserrat Light;*/">
            <?php echo $data->text; ?>

        </div>
        <div class="col-md-6 wow fadeInUp">
            <h4 class="tpn-red"><?php echo $data->subtitle; ?></h4>
            <img src="<?php echo isset( $data->image) ?  $data->image : null; ?>" alt="" class="">
            <img src="<?php echo isset( $data->image_2) ?  $data->image_2 : null; ?>" alt="" class="">
        </div>
    </div>
    <div class="row mt-5">
        <?php $__currentLoopData = $descarga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mb-5 wow fadeInUp"  data-wow-delay="0.<?php echo $k+1; ?>s">
            <div class="card z-depth-0 rounded-0" style="background-color: #F8F8F8; border: 1px solid #DDDDDD;">
                <div class="card-body" >
                    <div class="row">
                        <div class="col-md-10 d-flex align-items-center">
                            <div class="">
                                <span class="tpn-blue font-weight-bold"> <?php echo $d->title; ?></span>
                                <br>
                                <a href="<?php echo e($d->ficha); ?>" target="_blank"><span style="font-family: 'Montserrat Light'; color: #464646">Ver Certificado</span></a>
                            </div>
                        </div>
                        <div class="col-md-2 d-flex align-items-center">
                            <a href="<?php echo e(isset($d->ficha) ? $d->ficha : null); ?>" <?php echo e(isset($d->ficha) ? 'download' : null); ?>><i class="material-icons tpn-blue" style="font-size: 3rem;">file_download</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h4 class="tpn-blue font-weight-bold wow fadeInUp my-4"><?php echo $data->title_2; ?></h4>
    <div class="row">
        <div class="col-md-6 wow fadeInUp" style="/*font-family: Montserrat Light;*/">
            <?php echo $data->text_2; ?>

        </div>
        <div class="col-md-6 wow fadeInUp">
            <p style="/*font-family: Montserrat Light;*/"><?php echo $data->subtitle_2; ?></p>
            <?php $__currentLoopData = $imagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo $i->image; ?>" alt="" class="img-fluid">
                <p class="py-2"><b><?php echo $i->title; ?></b></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>