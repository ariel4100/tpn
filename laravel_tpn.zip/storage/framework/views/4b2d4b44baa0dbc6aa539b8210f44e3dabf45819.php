<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('novedad.index')); ?>"><< Volver</a>
        <form class="row" method="POST" action="<?php echo e(route('novedad.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="col-md-8">
                <div class="md-form">
                    <input type="text" id="title" name="title" class="form-control">
                    <label for="title" class="">Titulo</label>
                </div>
            </div>
            <div class="col-md-4">
                <div class="md-form">
                    <input type="text" id="order" name="order" class="form-control">
                    <label for="order" class="">Orden</label>
                </div>
            </div>
            <div class="col-md-12">
                <div class="md-form">
                    <h6>Subtitulo</h6>
                    <textarea id="subtitle" class="md-textarea form-control" name="text" rows="3"></textarea>
                </div>
            </div>
            <div class="col-md-6">
                <select name="categories_id" id="" class="form-control">
                    <option value="" selected disabled>Seleccionar categoria</option>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($c->id); ?>"><?php echo $c->title; ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option value="" disabled >No hay categorias</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="col-md-6">
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                    <label class="custom-file-label" for="customFileLang">Imagen Principal</label>
                </div>
            </div>
            <div class="col-md-12 mt-5">
                <label class="mb-0 ml-2" for="material-url">Video URL</label>
                <div class="md-form input-group mt-0 mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text md-addon" id="material-addon3">https://www.youtube.com/watch?v=</span>
                    </div>
                    <input type="text" class="form-control" id="material-url" name="video" aria-describedby="material-addon3">
                </div>
            </div>
            <div class="col-md-12 my-4 text-right">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('subtitle');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>