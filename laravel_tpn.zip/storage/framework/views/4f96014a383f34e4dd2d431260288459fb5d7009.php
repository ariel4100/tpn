<?php $__env->startSection('content'); ?>
<div class="container my-5 ">
    <div class="row d-flex justify-content-center align-items-center">
        <div class="col-md-6">
            <div class="bg-white p-5 rounded">
                <?php ($logos = \App\Content::seccionTipo('logos','texto')->first()); ?>
                <?php ($data = json_decode($logos->text)); ?>
                <div class="text-center">
                    <img src="<?php echo e($data->image); ?>" alt="" class="img-fluid">
                </div>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="md-form">
                            <i class="fas fa-user prefix"></i>
                            <input type="text" id="Usuario" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>">
                            <label for="Usuario">Nombre de Usuario</label>
                            <?php if($errors->has('username')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="md-form">
                            <i class="fas fa-envelope prefix"></i>
                            <input type="password" id="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
                            <label for="password">Contraseña</label>
                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                       
                        <div class="form-group text-right">
                                <button type="submit" class="btn text-white" style="background-color: #175B9F">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                
                        </div>
                    </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>