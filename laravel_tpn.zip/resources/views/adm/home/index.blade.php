@extends('adm.layouts.app')

@section('content')
<div class="container h-100 d-flex justify-content-center align-items-center">
<h1 class="my-5 animated  zoomIn">Bienvenido</h1>
</div>
@endsection
