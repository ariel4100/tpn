<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <form class="row" method="POST" action="<?php echo e(route('contenido.update', $contenido )); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="hidden" name="section" value="<?php echo e($section); ?>">
            <input type="hidden" name="type" value="<?php echo e($type); ?>">
            <?php if($section == 'home' || $section == 'flota'): ?>
                <div class="col-md-12">
                    <div class="md-form">
                        <h6>Texto</h6>
                        <textarea id="text" class="md-textarea form-control" name="text" rows="3"><?php echo isset($contenido) ? $contenido->text : null; ?></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                        <label class="custom-file-label" for="customFileLang">Seleccionar Imagen</label>
                    </div>
                </div>
                <div class="col-md-12 my-5 text-center">
                    <img src="<?php echo e($contenido->image); ?>" alt="" class="img-fluid">
                </div>
            <?php endif; ?>
            <?php if($section == 'empresa'): ?>

                <div class="col-md-12">
                    <div class="md-form">
                        <input type="text" id="Titulo" name="title" class="form-control" value="<?php echo isset($contenido) ? $contenido->title : null; ?>">
                        <label for="Titulo">Titulo</label>
                    </div>
                    <div class="md-form">
                        <h6>Texto</h6>
                        <textarea id="text" class="md-textarea form-control" rows="3"><?php echo isset($contenido) ? $contenido->text : null; ?></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <label class="mb-0 ml-2" for="material-url" >Video URL</label>
                    <div class="md-form input-group mt-0 mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text md-addon" id="material-addon3">https://www.youtube.com/watch?v=</span>
                        </div>
                        <input type="text" class="form-control" name="video" id="material-url" aria-describedby="material-addon3" value="<?php echo isset($contenido) ? $contenido->video : null; ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                        <label class="custom-file-label" for="customFileLang">Seleccionar Imagen</label>
                    </div>
                </div>
                <div class="col-md-12 my-5 text-center">
                    <img src="<?php echo e($contenido->image); ?>" alt="" class="img-fluid" style="height: 200px">
                </div>
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="text" id="Subtitulo" name="subtitle" class="form-control" value="<?php echo isset($contenido) ? $contenido->subtitle : null; ?>">
                        <label for="Subtitulo">Subtitulo</label>
                    </div>
                </div>
                <div class="col-md-6 d-flex align-items-center">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="defaultUnchecked" name="destacado" <?php echo $contenido->destacado ? 'checked' : null; ?>>
                        <label class="custom-control-label" for="defaultUnchecked">Home?</label>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($section == 'clientes'): ?>
                <div class="col-md-12">
                    <div class="md-form">
                        <h6>Texto</h6>
                        <textarea id="text" class="md-textarea form-control" name="text" rows="3"><?php echo isset($contenido) ? $contenido->text : null; ?></textarea>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($section == 'calidad'): ?>
                <div class="col-md-12">
                    <div class="md-form">
                        <input type="text" id="Titulo" name="title" class="form-control" value="<?php echo isset($data['title']) ? $data['title'] : null; ?>">
                        <label for="Titulo">Titulo</label>
                    </div>
                    <div class="md-form">
                        <h6>Texto</h6>
                        <textarea id="text" class="md-textarea form-control" name="text" rows="3"><?php echo isset($data['text']) ? $data['text'] : null; ?></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="md-form">
                        <input type="text" id="Subtitulo" name="subtitle" class="form-control" value="<?php echo isset($data['subtitle']) ? $data['subtitle'] : null; ?>">
                        <label for="Subtitulo">Subtitulo</label>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="md-form">
                        <input type="text" id="title_2" name="title_2" class="form-control" value="<?php echo isset($data['title_2']) ? $data['title_2'] : null; ?>">
                        <label for="title_2">Titulo</label>
                    </div>
                    <div class="md-form">
                        <h6>Texto</h6>
                        <textarea id="text_2" class="md-textarea form-control" name="text_2" rows="3"><?php echo isset($data['text_2']) ? $data['text_2'] : null; ?></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="md-form">
                        <input type="text" id="Subtitulo_2" name="subtitle_2" class="form-control" value="<?php echo isset($data['subtitle_2']) ? $data['subtitle_2']: null; ?>">
                        <label for="Subtitulo_2">Subtitulo</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                        <label class="custom-file-label" for="customFileLang">Seleccionar Imagen</label>
                    </div>
                    <img src="<?php echo isset($data['image']) ? $data['image']: null; ?>" alt="" class="img-fluid">
                </div>
                <div class="col-md-6">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFileLang" name="image_2" lang="es">
                        <label class="custom-file-label" for="customFileLang">Seleccionar Imagen</label>
                    </div>
                    <img src="<?php echo isset($data['image_2']) ? $data['image_2']: null; ?>" alt="" class="img-fluid" >
                </div>
            <?php endif; ?>
            <?php if($section == 'logos'): ?>
                <div class="col-md-12 text-center">
                    <div class="col-md-12">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="Favicon" name="image" lang="es">
                            <label class="custom-file-label" for="Favicon">Seleccionar Logo Favicon</label>
                        </div>
                        <img src="<?php echo isset($data['image']) ? $data['image'] : null; ?>" alt="" class="img-fluid my-4">
                    </div>
                    <div class="col-md-12">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="Header" name="image_2" lang="es">
                            <label class="custom-file-label" for="Header">Seleccionar Logo Header</label>
                        </div>
                        <img src="<?php echo isset($data['image_2']) ? $data['image_2'] : null; ?>" alt="" class="img-fluid my-4">
                    </div>
                    <div class="col-md-12">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="Footer" name="image_3" lang="es">
                            <label class="custom-file-label" for="Footer">Seleccionar Logo Footer</label>
                        </div>
                        <img src="<?php echo isset($data['image_3']) ? $data['image_3'] : null; ?>" alt="" class="img-fluid my-4">
                    </div>
                </div>
            <?php endif; ?>
            <?php if($section == 'contacto'): ?>
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="text" id="Titulo" name="title" class="form-control" value="<?php echo isset($data) ? $data['title'] : null; ?>">
                        <label for="Titulo">Titulo</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="Dirección" name="direccion" class="form-control" value="<?php echo isset($data) ? $data['direccion'] : null; ?>">
                        <label for="Dirección">Dirección</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="Telefono_1" name="telefono_1" class="form-control" value="<?php echo isset($data) ? $data['telefono_1'] : null; ?>">
                        <label for="Telefono_1">Telefono 1</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="Telefono_2" name="telefono_2" class="form-control" value="<?php echo isset($data) ? $data['telefono_2'] : null; ?>">
                        <label for="Telefono_2">Telefono 2</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="Correo" name="correo" class="form-control" value="<?php echo isset($data) ? $data['correo'] : null; ?>">
                        <label for="Correo">Correo</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="text" id="title_2" name="title_2" class="form-control" value="<?php echo isset($data) ? $data['title_2'] : null; ?>">
                        <label for="title_2">Titulo</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="direccion_2" name="direccion_2" class="form-control" value="<?php echo isset($data) ? $data['direccion_2'] : null; ?>">
                        <label for="direccion_2">Dirección</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="central_telefono_1" name="central_telefono_1" class="form-control" value="<?php echo isset($data) ? $data['central_telefono_1'] : null; ?>">
                        <label for="central_telefono_1">Telefono 1</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="central_telefono_2" name="central_telefono_2" class="form-control" value="<?php echo isset($data) ? $data['central_telefono_2'] : null; ?>">
                        <label for="central_telefono_2">Telefono 2</label>
                    </div>
                    <div class="md-form">
                        <input type="text" id="correo_2" name="correo_2" class="form-control" value="<?php echo isset($data) ? $data['correo_2'] : null; ?>">
                        <label for="correo_2">Correo</label>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-md-12 my-4 text-right">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('text');
        CKEDITOR.replace('text_2');
        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>