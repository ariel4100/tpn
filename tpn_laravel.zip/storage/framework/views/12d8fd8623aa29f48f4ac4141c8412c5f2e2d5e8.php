<div class="container-fluid">
    <div class="row">
        <div class="container">
            <div class="d-flex justify-content-end"  >
                <a href="http://tpn.setuponline.com.ar" target="_blank" class="p-2" style="color: #B0B0B0;">SEGUIMIENTO DE CARGA</a>
                <a href="<?php echo e(route('presupuesto')); ?>" class="p-2 <?php echo e(request()->is('presupuesto') ? 'activo' : ''); ?>" style="color: #B0B0B0;">SOLICITUD DE PRESUPUESTO</a>
                <div class="p-2 bd-highlight">
                    <a href="" class="tpn-red"><i class="fas fa-search"></i></a>
                    <a href="" class="tpn-blue mx-2"><i class="fab fa-facebook"></i></a>
                    <a href="" class="tpn-blue"><i class="fab fa-youtube"></i></a>
                </div>

            </div>
        </div>
    </div>
</div>
<?php ($logos = \App\Content::seccionTipo('logos','texto')->first()); ?>
<?php ($data = json_decode($logos->text)); ?>
<nav class="navbar navbar-expand-lg navbar-light bg-white py-0" style="box-shadow: unset; ">
<div class="container">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo $data->image; ?>" alt="" class="img-fluid"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is('empresa') ? 'activo' : ''); ?>" href="<?php echo e(route('empresa')); ?>">Empresa</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is('servicios') ? 'activo' : ''); ?>" href="<?php echo e(route('servicios')); ?>">Servicios</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is('flota') ? 'activo' : ''); ?>" href="<?php echo e(route('flota')); ?>">Flota</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is('clientes') ? 'activo' : ''); ?>" href="<?php echo e(route('clientes')); ?>">Clientes</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is('politica-de-calidad') ? 'activo' : ''); ?>" href="<?php echo e(route('calidad')); ?>">Política de Calidad</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is('solidaria*') ? 'activo' : ''); ?>" href="<?php echo e(route('solidaria')); ?>">TPN solidaria</a></li>
            <li class="nav-item"><a class="nav-link <?php echo e(request()->is('contacto') ? 'activo' : ''); ?>" href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
            <a href="<?php echo e(route('pedido')); ?>" class="btn btn-md my-2 my-sm-0 <?php echo e(request()->is('pedido') ? 'btn-outline-danger' : 'btn-outline-dark'); ?>">PEDIDO DE RETIRO</a>

        </ul>
    </div>
</div>
</nav>