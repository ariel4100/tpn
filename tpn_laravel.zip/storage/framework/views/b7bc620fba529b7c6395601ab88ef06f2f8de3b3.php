<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row align-items-center">
        <div class="col-md-9">
            <?php $__empty_1 = true; $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="row align-items-end">
                    <div class="col-md-4 wow fadeIn">
                        <span class="tpn-blue p-2 font-weight-bold" style="background-color: #ECECEC;"><?php echo $n->Category->title; ?></span>
                        <img src="<?php echo $n->image; ?>" alt="" class="img-fluid">
                    </div>
                    <div class="col-md-8 wow fadeIn" style="font-family: Montserrat Light;">
                        <h4 class="tpn-blue font-weight-bold"><?php echo $n->title; ?></h4>
                        <?php echo Str::limit($n->text,200); ?>

                        <br>
                        <b><a href="<?php echo e(route('solidaria_blog',$n)); ?>" class="text-uppercase tpn-red" style="font-size: 12px !important;"><i class="fas fa-arrow-right"></i> Ver más</a></b>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>No hay registros</h4>
            <?php endif; ?>
        </div>
        <div class="col-md-3 wow fadeIn">
            <h4 class="mb-4 tpn-red">Categorias</h4>
            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <p class="m-0"><a href="" class="" style="color: #000;">>> <?php echo $c->title; ?></a></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No hay registros</p>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>