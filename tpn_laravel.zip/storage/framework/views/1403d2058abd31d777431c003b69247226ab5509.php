<?php $__env->startSection('content'); ?>
 <?php echo $__env->make('page.partials.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container py-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-8">
            <?php $__empty_1 = true; $__currentLoopData = $flotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="row mb-4 wow fadeInUp" data-wow-delay="0.<?php echo e($k*2); ?>s">
                    <div class="col-md-2 text-right">
                        <img src="<?php echo $f->image; ?>" alt="" class="img-fluid">
                    </div>
                    <div class="col-md-10" style="font-family: 'Montserrat Light'">
                        <?php echo $f->text; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h4>No hay registros</h4>
            <?php endif; ?>
        </div>
    </div>
</div>
 <div class="d-flex align-items-center justify-content-center" style="background-image: url('<?php echo $flota->image; ?>'); height: 300px; background-repeat: no-repeat; background-position: center; background-size: cover;">
     <div class="container" >
         <div class="row">
             <div class="col-md-8 wow fadeInDown">
                  <?php echo $flota->text; ?>

             </div>
         </div>
     </div>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>