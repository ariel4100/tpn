<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col-md-12 wow fadeInDown" style="font-family: 'Montserrat Light'">
                <?php echo $cliente->text; ?>

            </div>
        </div>
    </div>
<div class="container">
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3 wow fadeInDown" data-wow-delay="0.<?php echo e($key*3); ?>s" style="padding: unset;">
            <div class="d-flex justify-content-center align-items-center" style="height: 250px; background-color: rgba(62, 69, 81, 0.02); border: 1px solid rgba(62, 69, 81, 0.1)">
                <img src="<?php echo $c->image; ?>" alt="" class="img-fluid">
            </div>
            <p class="text-center py-2"><?php echo $c->title; ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h4>No hay registros</h4>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>